package com.example.People.controller;

import com.example.People.model.Item;
import com.example.People.service.ItemService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("/people")
@RestController
public class ItemController {
    private final ItemService itemService;

    public ItemController(ItemService itemService) {
        this.itemService = itemService;
    }

    @GetMapping("/getAllItems")
    public List<Item> getAllItems() {
        return itemService.getAllItems();
    }

    @GetMapping("/get/{itemID}")
    public Item getItem(@PathVariable String itemID) {
        return itemService.getItem(itemID);
    }

    
}
