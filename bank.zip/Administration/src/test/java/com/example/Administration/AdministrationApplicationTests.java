package com.example.Administration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdministrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
